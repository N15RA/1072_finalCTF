<?php

highlight_file(__FILE__);

include('flag.php');

if(isset($_GET['input']))
{
	$in = $_GET['input'];
	$ans = 1;

	if(preg_match('/^1\.0+$/s', (string)$in) || $in === 'true' || $in === '1') echo 'GG';
	else if($in == $ans) echo 'good';
}

?>