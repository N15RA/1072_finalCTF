<?php header('Flag: NISRA{y0u_kn0w_how_t0_us3_F12}'); ?>

<h1>Can You Find The Flag?</h1>