# developer tool
* Flag: `NISRA{y0u_kn0w_how_t0_us3_F12}`

# php proto
* Flag: `NISRA{pr0t0_1s_g0o0o0o0o0o0o0o0o0d}`

# 1==1?
[hint](https://www.sherlocklee.top/2018/08/19/php%E7%BC%BA%E9%99%B7%E6%BC%8F%E6%B4%9E/)
* Flag: `NISRA{f1o4t_i5_n0t_pr3cise!}`